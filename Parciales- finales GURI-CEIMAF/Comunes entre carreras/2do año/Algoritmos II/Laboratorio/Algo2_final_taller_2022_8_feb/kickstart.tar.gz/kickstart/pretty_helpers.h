#ifndef PRETY_HELPER_H
#define PRETY_HELPER_H

#include <stdio.h>

void color_no_color(void);

void color_blue(void);

void color_green(void);

void color_lightgreen(void);

void color_gold(void);

void color_gray(void);

void color_cyan(void);

void color_red(void);

void color_lightred(void);

void color_white(void);

#endif
